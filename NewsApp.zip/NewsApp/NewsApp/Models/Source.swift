//
//  Source.swift
//
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import Foundation
import Moya
import ObjectMapper

class Source: Mappable {
    
    var status: String?
    var articles: [Article]?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        articles <- map["articles"]
    }
}

class Article: Mappable {
    var author: String?
    var title: String?
    var description: String?
    var urlToImage: String?
    var publishedAt: String?
    var name: [Author]?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        author <- map["author"]
        title <- map["title"]
        description <- map["description"]
        urlToImage <- map["urlToImage"]
        publishedAt <- map["publishedAt"]
        name <- map["source"]
    }
}
class Author: Mappable {
    
    var id: String?
    var name: String?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        id <- map["id"]
        name <- map["name"]
    }
}
