//
//  Articles.swift
//
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import Foundation
import Alamofire
import Moya
import ObjectMapper

class Articles: NSObject, Mappable {
    
    var publishedAt: String?
    var descriptionValue: String?
    var title: String?
    var urlToImage: String?
    var author: String?
    var url: String?
    
    override init() {
        super.init()
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        publishedAt <- map["publishedAt"]
        descriptionValue <- map["description"]
        title <- map["title"]
        urlToImage <- map["urlToImage"]
        author <- map["author"]
        url <- map["url"]
    }
    
}

