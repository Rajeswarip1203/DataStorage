//
//  WeatherGetter.swift
//  SimpleWeather
//
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//


import Foundation
import Alamofire

class WeatherGetter {
    
    private var _date: Double?
    private var _temp: String?
    private var _location: String?
    private var _weather: String?
    private var _maxtemp: String?
    private var _mintemp: String?
    typealias JSONStandard = Dictionary<String, AnyObject>
    let url = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=Bangalore&appid=b4e73c3361f92dabc187da048f9e4901")!
    
    var date: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .none
        let date = Date(timeIntervalSince1970: _date!)
        return (_date != nil) ? "Today, \(dateFormatter.string(from: date))" : "Date Invalid"
    }
    
    var temp: String {
        return _temp ?? "0 °C"
    }
    
    var maxtemp: String {
        return _maxtemp ?? "0 °C"
    }
    
    var mintemp: String {
        return _mintemp ?? "0 °C"
    }
    
    var location: String {
        return _location ?? "Location Invalid"
    }
    
    var weather: String {
        return _weather ?? "Weather Invalid"
    }
    
    func getWeather(completed: @escaping ()-> ()) {
        
        Alamofire.request(url).responseJSON(completionHandler: {
            response in
            let result = response.result
            
            if let dict = result.value as? JSONStandard, let main = dict["main"] as? JSONStandard, let temp = main["temp"] as? Double, let minTemp = main["temp_min"] as? Double, let maxTemp = main["temp_max"] as? Double, let weatherArray = dict["weather"] as? [JSONStandard], let weather = weatherArray[0]["main"] as? String, let name = dict["name"] as? String, let sys = dict["sys"] as? JSONStandard, let country = sys["country"] as? String, let dt = dict["dt"] as? Double {
                self._temp = String(format: "%.0f °C", temp - 273.15)
                self._maxtemp = String(format: "%.0f ", maxTemp - 273.15)
                self._mintemp = String(format: "%.0f ", minTemp - 273.15)
                self._weather = weather
                self._location = "\(name), \(country)"
                self._date = dt
            }
            completed()
        })
    }
    
}
