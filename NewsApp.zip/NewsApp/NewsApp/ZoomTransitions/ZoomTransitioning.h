//
//  ZoomTransitioning.h
//  ZoomTransitioning
//
//  Created by shoji on 7/19/16.
//  Copyright © 2016 com.shoji. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZoomTransitioning.
FOUNDATION_EXPORT double ZoomTransitioningVersionNumber;

//! Project version string for ZoomTransitioning.
FOUNDATION_EXPORT const unsigned char ZoomTransitioningVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZoomTransitioning/PublicHeader.h>


