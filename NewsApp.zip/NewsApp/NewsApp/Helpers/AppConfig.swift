//
//  AppConfig.swift
//  zone
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import Foundation

struct AppConfig {
    
    static let borderWidth = 1
    
}
