//
//  DetailsPageViewController.swift
//  NewsApp
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import UIKit
import SQLite3

class DetailsPageViewController: UIViewController {
    var db:OpaquePointer?
    @IBOutlet weak var userProfile: UIImageView!
    @IBOutlet weak var newsDescription: UILabel!
    @IBOutlet weak var newsLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var favirote: UIButton!
    
    var dateString  = String()
    var profileUrl  = String()
    var descriptionString = String()
    var author = String()
    var checked = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getValuesfromNewsListView()
        checkTableExistiing ()
        readValuesFromTable()
    }
    
    func getValuesfromNewsListView() {
        newsDescription.text = descriptionString
        authorLabel.text = author
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        let date = dateFormatter.date(from: dateString)
        dateFormatter.dateFormat = " d MMM yyyy ,h:mm a"
        dateFormatter.timeZone = TimeZone.current
        if dateString.isEmpty == false{
            let timeStamp = dateFormatter.string(from: date!)
            dateLabel.text = timeStamp
        }else {}
        if profileUrl.isEmpty == false {
            loadImageFromUrl(url: profileUrl, view: userProfile)
        }
        setBorderLabel(label: newsLabel)
    }
    
    @IBAction func onTapBackButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func checkTableExistiing () {
        let fileUrl=try!
            FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("NewsDatabse.sqlite")
        if sqlite3_open(fileUrl.path,&db) != SQLITE_OK
        {
            print("Error opening Database")
            return
        }
        let createTableQuery = "CREATE TABLE IF NOT EXISTS Newslist_table (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,description TEXT)"
        if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK
        {
            print("Error create table")
            return
        }
        print("Everything Fine")
    }
    
    @IBAction func onTapFavourite(_ sender: UIButton) {
        if checked {
            sender.setImage( UIImage(named:"Star"), for: .normal)
            checked = false
            displayAlertMessage(title: "Detail Page", messageToDisplay: " Not implemented remove favourite Data From Database")
        } else {
            sender.setImage(UIImage(named:"Star_selected"), for: .normal)
            checked = true
            let name=authorLabel.text
            let description=newsDescription.text
            var stmt :OpaquePointer?
            let insertQuery = "INSERT INTO Newslist_table (name,description) VALUES (?,?)"
            if sqlite3_prepare(db, insertQuery, -1, &stmt, nil) != SQLITE_OK {
                print("Error binding query")
            }
            if sqlite3_bind_text(stmt, 1, name, -1, nil) != SQLITE_OK {
                print("Error binding name")
            }
            if sqlite3_bind_text(stmt, 2, description, -1, nil) != SQLITE_OK {
                print("Error binding description")
            }
            if sqlite3_step(stmt) == SQLITE_DONE {
                print("News saved successfully")
                displayAlertMessage(title: "Detail Page", messageToDisplay: " Record is Successfully saved!")
            }
        }
    }
    
    func readValuesFromTable(){
        let queryString = "SELECT * FROM Newslist_table"
        var stmt:OpaquePointer?
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return
        }
        while(sqlite3_step(stmt) == SQLITE_ROW){
            let author = String(cString: sqlite3_column_text(stmt, 1))
            let description = String(cString: sqlite3_column_text(stmt, 2))
            print(author)
            print(description)
            if (author==authorLabel.text) || (description==newsDescription.text ) {
                favirote.setImage(UIImage(named:"Star_selected"), for: .normal)
                
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
