//
//  ViewController.swift
//  NewsApp
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var emailIdField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onTapLogin(_ sender: Any) {
        let emailid=emailIdField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password=passwordField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        if (emailid?.isEmpty)! {
            displayAlertMessage(messageToDisplay: "Please enter emailid! ")
            return
        }
        if (password?.isEmpty)! {
            displayAlertMessage(messageToDisplay: "Please enter password! ")
            return
        }
        if Connectivity.isConnectedToInternet {
            if ((emailIdField.text == "Rahul.r@gmail.com") && (passwordField.text == "demo")){
                let url = "http://184.106.114.93/DemoApp/Login?Email=Rahul.r@gmail.com&Password=demo"
                indicator.startAnimating()
                Alamofire.request(url).responseJSON { response in
                    if response.data?.isEmpty == false {
                        self.indicator.startAnimating()
                        let defaults = UserDefaults.standard
                        defaults.set(self.emailIdField.text, forKey: "EmailID")
                        self.gotoNextView()
                    }
                }
            }else  {
                displayAlertMessage(messageToDisplay: "Please enter correct emailid and password!")
            }
        }else {
            displayAlertMessage(messageToDisplay: "No Internet Connection!")
        }
    }
    
    func gotoNextView() {
        let VC1 = self.storyboard!.instantiateViewController(withIdentifier: "NewsListVC") as! NewsListViewController
        let navController = UINavigationController(rootViewController: VC1)
        self.present(navController, animated:true, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

