//
//  EditProfileViewController.swift
//  NewsApp
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import UIKit
import Alamofire
class EditProfileViewController: BaseViewController , UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UITextFieldDelegate  {
    
    @IBOutlet weak var profilePicture: UIImageView!
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var emailId: UITextField!
    var pickerController = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profilePicture.layer.borderWidth = 1
        profilePicture.layer.masksToBounds = false
        profilePicture.layer.borderColor = UIColor.black.cgColor
        profilePicture.layer.cornerRadius = profilePicture.frame.height/2
        profilePicture.clipsToBounds = true
    }
    
    @IBAction func onTapUpdate(_ sender: Any) {
        if let fname = firstName.text, !fname.isEmpty,let lname = lastName.text, !lname.isEmpty, let address = address.text, !address.isEmpty, let emailid = emailId.text, !emailid.isEmpty{
            updateUserDetails()
            
        }else {
            self.displayAlertMessage(title: "Edit Profile", messageToDisplay: "please enter all fields!")
        }
    }
    
    @IBAction func openCameraButton(sender: AnyObject) {
        let alertViewController = UIAlertController(title: "", message: "Choose your option", preferredStyle: .actionSheet)
        
        let camera = UIAlertAction(title: "Camera", style: .default, handler: { (alert) in
            self.openCamera()
        })
        let gallery = UIAlertAction(title: "Gallery", style: .default) { (alert) in
            self.openGallary()
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (alert) in
            
        }
        alertViewController.addAction(camera)
        alertViewController.addAction(gallery)
        alertViewController.addAction(cancel)
        self.present(alertViewController, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            pickerController.delegate = self
            self.pickerController.sourceType = UIImagePickerControllerSourceType.camera
            pickerController.allowsEditing = true
            self .present(self.pickerController, animated: true, completion: nil)
        }
        else {
            self.displayAlertMessage(title: "Camera", messageToDisplay: "You don't have camera!")
        }
    }
    
    func openGallary() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            pickerController.delegate = self
            pickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
            pickerController.allowsEditing = true
            self.present(pickerController, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let photo = info[UIImagePickerControllerOriginalImage] as! UIImage
        profilePicture.image = photo
        dismiss(animated: true, completion: nil)
    }
    
    func updateUserDetails() {
        let imgObj = UIImage(named: "Profile")
        let imageData = UIImagePNGRepresentation(imgObj!)! as NSData
        let base64 = imageData.base64EncodedData(options: .lineLength64Characters)
        print(base64)
        let urlString = "http://184.106.114.93/DemoApp/UpdateUser"
        let params : Parameters = [
            "FirstName": firstName.text!,
            "LastName": lastName.text!,
            "Email": emailId.text!,
            "Address": address.text!,
            "byteArray": base64
        ]
        if Connectivity.isConnectedToInternet {
            let manager = Alamofire.SessionManager.default
            manager.session.configuration.timeoutIntervalForRequest = 120
            manager.request(urlString, method: .post, parameters: params)
                .responseJSON {  response in
                    switch response.result {
                    case .success:
                        self.displayAlertMessage(title: "Edit Profile", messageToDisplay: "Successfully updated!")
                        break
                    case .failure(let error):
                        self.displayAlertMessage(title: "Error", messageToDisplay: error.localizedDescription)
                    }
            }
        }else {
            displayAlertMessage(messageToDisplay: "No Internet Connection!")
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    textField.resignFirstResponder()
    return true
    }
    
    func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
