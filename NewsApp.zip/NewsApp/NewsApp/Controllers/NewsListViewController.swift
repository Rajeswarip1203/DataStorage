//
//  NewsListViewController.swift
//  NewsApp
//
//  Created by Rajeswari on 01/07/18.
//  Copyright © 2018 planklabs.com. All rights reserved.
//

import UIKit
import Alamofire
import ObjectMapper
import AlamofireObjectMapper

class NewsListViewController: BaseViewController,  UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collectionView: UICollectionView!
    var newsDetails:[Article] = []
    @IBOutlet weak var newsView: UIView!
    @IBOutlet weak var fashionView: UIView!
    @IBOutlet weak var modelsView: UIView!
    @IBOutlet weak var localView: UIView!
    @IBOutlet weak var fashionButton: UIButton!
    @IBOutlet weak var modelsButton: UIButton!
    @IBOutlet weak var newsButton: UIButton!
    @IBOutlet weak var localButton: UIButton!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getNewsList()
        self.addSlideMenuButton()
        newsView.backgroundColor = UIColor.lightGray
    }
    
    func getNewsList() {
        if Connectivity.isConnectedToInternet {
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            let url = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=a2cb27a220f244ceb6e39c1eb503c426"
            Alamofire.request(url).responseObject { (response: DataResponse<Source>) in
                let jsonResponse = response.result.value
                if let courceDetails = jsonResponse?.articles {
                    for news in courceDetails {
                        self.newsDetails.append(news)
                    }
                }
                self.collectionView.reloadData()
            }
        }else {
            displayAlertMessage(messageToDisplay: "No Internet Connection!")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  newsDetails.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newsListCell", for: indexPath) as! NewsListCollectionViewCell
        cell.layer.masksToBounds = true
        cell.layer.cornerRadius = 4
        cell.layer.borderWidth = 1
        cell.layer.shadowOffset = CGSize(width: -1, height: 1)
        let borderColor: UIColor = UIColor.lightGray
        cell.layer.borderColor = borderColor.cgColor
        cell.title.text = newsDetails[indexPath.row].title
        let str = newsDetails[indexPath.row].urlToImage
        if str?.isEmpty == false {
            loadImageFromUrl(url: str!, view: cell.userImage)
        }else {
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DetailsPageVC") as? DetailsPageViewController
        let description = newsDetails[indexPath.row].description
        if  description?.isEmpty == false {
            vc?.descriptionString = description!
        }else {
            vc?.author = "No Description"
        }
        vc?.profileUrl = newsDetails[indexPath.row].urlToImage!
        vc?.dateString = newsDetails[indexPath.row].publishedAt!
        let authorString  = newsDetails[indexPath.row].author
        if authorString?.isEmpty == false {
            vc?.author = authorString!
        }else {
            vc?.author = "No author"
        }
        vc?.modalPresentationStyle = .custom
        vc?.modalTransitionStyle = .crossDissolve
        self.present(vc!, animated: true, completion: nil)
    }
    
    @IBAction func onTapNews(_ sender: Any) {
        getAlltheViews(movies: UIColor.lightGray, fashion: UIColor.white, local: UIColor.white, models: UIColor.white)
    }
    
    @IBAction func onTapFashion(_ sender: Any) {
        getAlltheViews(movies: UIColor.white, fashion: UIColor.lightGray, local: UIColor.white, models: UIColor.white)
    }
    
    @IBAction func onTapModels(_ sender: Any) {
        getAlltheViews(movies: UIColor.white, fashion: UIColor.white, local: UIColor.white, models: UIColor.lightGray)
    }
    
    @IBAction func onTapLocal(_ sender: Any) {
        getAlltheViews(movies: UIColor.white, fashion: UIColor.white, local: UIColor.lightGray, models: UIColor.white)
    }
    
    func  getAlltheViews(movies: UIColor, fashion: UIColor, local: UIColor, models: UIColor) {
        fashionView.backgroundColor = fashion
        newsView.backgroundColor = movies
        localView.backgroundColor = local
        modelsView.backgroundColor = models
        self.collectionView.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

